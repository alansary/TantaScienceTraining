#include <iostream>
using std::cout;
using std::cin;
using std::endl;

int main() {
    int A, B, X;
    cin >> A;
    cin >> B;
    X = A + B;
    cout << "X = " << X << endl;
    return 0;
}
