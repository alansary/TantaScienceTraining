#include<stdio.h>
using namespace std;
int main() {
    int dist;
    scanf("%d", &dist);
    printf("%d minutos\n", (dist * 60) / 30);
    return 0;
}
