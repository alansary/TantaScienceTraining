#include<stdio.h>
using namespace std;
int main() {
    int A, B, C, D, DIFFERENCE;
    scanf("%d", &A);
    scanf("%d", &B);
    scanf("%d", &C);
    scanf("%d", &D);
    DIFFERENCE = A * B - C * D;
    printf("DIFERENCA = %d\n", DIFFERENCE);
    return 0;
}
