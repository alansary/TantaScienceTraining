#include<stdio.h>
using namespace std;
int main() {
    int A, B, SOMA;
    scanf("%d", &A);
    scanf("%d", &B);
    SOMA = A + B;
    printf("SOMA = %d\n", SOMA);
    return 0;
}
