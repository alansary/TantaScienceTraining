#include<stdio.h>
using namespace std;
int main() {
    int A, B, PROD;
    scanf("%d", &A);
    scanf("%d", &B);
    PROD = A * B;
    printf("PROD = %d\n", PROD);
    return 0;
}
